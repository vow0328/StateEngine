#ifndef ACTION_STATE_TRANSITION_SAMPLE_H
#define ACTION_STATE_TRANSITION_SAMPLE_H

#include "MainStat.h"
#include "TriggerDefine_Sample.h"

/* 井字棋内部触发器 */
#define TRIG_TTT_TO_X          ((UI_16)0x0A01u)
#define TRIG_TTT_TO_O          ((UI_16)0x0A02u)
#define TRIG_TTT_X_WIN         ((UI_16)0x0A03u)
#define TRIG_TTT_O_WIN         ((UI_16)0x0A04u)
#define TRIG_TTT_DRAW          ((UI_16)0x0A05u)
#define TRIG_TTT_TO_CPU        ((UI_16)0x0A06u)
#define TRIG_TTT_COMPUTER_DONE ((UI_16)0x0A07u)

#define TRIG_TTT_START_2P  ((UI_16)0x0B01u)
#define TRIG_TTT_START_CPU ((UI_16)0x0B02u)
#define TRIG_TTT_QUIT      ((UI_16)0x0B03u)
#define TRIG_TTT_REPLAY    ((UI_16)0x0B04u)
#define TRIG_TTT_MENU      ((UI_16)0x0B05u)

/* 菜单、结果画面的选择项 */
#define TTT_MENU_2P   0u
#define TTT_MENU_CPU  1u
#define TTT_MENU_QUIT 2u

#define TTT_RESULT_REPLAY 0u
#define TTT_RESULT_MENU   1u

/* 对战模式：双人，或玩家执 X / 电脑执 O */
#define TTT_MODE_2P  0u
#define TTT_MODE_CPU 1u

/* 引擎提供的特殊迁移目标（定义在 MainStat.c） */
extern const StateType_t TblPreviousState;  /* 回退到上一状态（出栈） */
extern const StateType_t TblFormEntryState; /* 取当前状态（栈顶，不弹栈） */

/* 调试用：当前状态栈深度（引擎实现） */
UI_8 GetStateStackDepth(void);

/* 井字棋状态表 */
extern const StateType_t TblTttMenu;
extern const StateType_t TblTttMenuDecide;
extern const StateType_t TblTttXTurn;
extern const StateType_t TblTttOTurn;
extern const StateType_t TblTttCheck;
extern const StateType_t TblTttComputerTurn;
extern const StateType_t TblTttXWin;
extern const StateType_t TblTttOWin;
extern const StateType_t TblTttDraw;
extern const StateType_t TblTttResultDecide;
extern const StateType_t TblTttQuit;

/* 屏幕层读取棋盘数据的只读接口（数据由 Action 层持有） */
char TttGetCell(UI_8 idx);
UI_8 TttGetCursor(void);
char TttGetCurrentMover(void);
UI_8 TttGetMenuSel(void);
UI_8 TttGetResultSel(void);
UI_8 TttGetMode(void);
const char *TttGetNotice(void);

#endif /* ACTION_STATE_TRANSITION_SAMPLE_H */
