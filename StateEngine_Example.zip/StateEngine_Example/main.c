#include <stdio.h>
#include "MainStat.h"
#include "Action_StateTransition_Sample.h"
#include "Screen_StateTransition_Sample.h"

int main(void)
{
    UI_16 key;

    TttScreenInit();
    MainStateEngineInit(&TblTttMenu);
    TttRenderCurrentScreen();

    for (;;)
    {
        key = TttScreenReadTrigger();

        if (key == SCREEN_KEY_QUIT)
        {
            printf("\n退出。\n");
            break;
        }

        if (key == SCREEN_KEY_NONE)
        {
            continue;
        }

        MainStateEngine(key);
        TttRenderCurrentScreen();

        /* 菜单选择“退出”后进入终止状态 */
        if (GetStateTbl() == &TblTttQuit)
        {
            break;
        }
    }

    return 0;
}
